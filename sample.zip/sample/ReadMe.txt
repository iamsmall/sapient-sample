
This page has been created with:
Angular 1.5.8
Bootstrap v3.3.7 (http://getbootstrap.com) the bootstrap is now intergrated with the sass
Sass

Dependencies Needed - 

Gulp
Gulp Sass  
Gulp Sourcemaps
Gulp Clean CSS
Gulp Browser Synch
Gulp SFTP

Installs for command line 

npm install gulp   //Gulp

npm install gulp-sass   //Gulp Sass

npm install gulp-sourcemaps  //Gulp Sourcemaps

npm install gulp-clean-css  //Gulp Minifies CSS

npm install gulp-sftp //Gulp SFTP

npm install browser-sync //Gulp Browser Sync

If you need more information for these dependencies please go to - https://www.npmjs.com/




